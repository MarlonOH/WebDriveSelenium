# PruebaWebDriveSelenium
pruebas de selenium con webdrive
#
# a traves del web drive de chrome se logra capturar el
# titular mas resiente de la pagina de "el colombiano"
# y te lo muestra en consula
