from selenium import webdriver
from selenium.webdriver.common.by import By
import time

#ultima noticia del colombiano con Web Scraping (Python y Selenium)

PATH = 'C:/chrome_webdriver/chromedriver.exe'


driver = webdriver.Chrome(PATH)
#driver = webdriver.Firefox(executable_path="C:/firefox_webdriver/geckodriver.exe")

driver.get(input("ingrese el link de youtube"))

#time.sleep(0)


newYoutube=driver.find_element(By.CLASS_NAME, "style-scope ytd-text-inline-expander")
print('La descripcion del video es: '+ newYoutube.text)

driver.quit()